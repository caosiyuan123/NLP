import os
import re
import jieba
import numpy as np
import matplotlib.pyplot as plt
from collections import Counter

def load_text(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()
    return text

def preprocess_text(text):
    # 去除标点符号和特殊字符
    text = re.sub(r'[^\w\s]', '', text)
    # 将文本转换为小写
    # text = text.lower()
    return text

def calculate_word_frequency(text):
    # 中文分词
    words = jieba.lcut(text)
    # 计算词频
    word_freq = Counter(words)
    return word_freq

def zipfs_law_plot(word_freq):
    # 根据词频排序
    sorted_freq = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    # 提取前5000个词及其频率
    top_words = sorted_freq[:5000]
    ranks = range(1, len(top_words) + 1)
    freqs = [pair[1] for pair in top_words]
    # 对数化处理
    log_ranks = np.log(ranks)
    log_freqs = np.log(freqs)
    # 绘制曲线
    plt.figure(figsize=(10, 6))
    plt.plot(log_ranks, log_freqs, marker='o')
    plt.xlabel('Log Rank')
    plt.ylabel('Log Frequency')
    plt.title('Zipf\'s Law')
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    folder_path = '1'
    file_names = os.listdir(folder_path)
    for file_name in file_names:
        file_path = os.path.join(folder_path, file_name)
        text = load_text(file_path)
        text = preprocess_text(text)
        word_freq = calculate_word_frequency(text)
        zipfs_law_plot(word_freq)
