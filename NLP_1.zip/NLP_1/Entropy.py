import os
import jieba
from collections import Counter
import math
import re

# 读取文件夹中的所有txt文件并整合在一起
def read_folder(folder_path):
    all_text = ''
    for file_name in os.listdir(folder_path):
        if file_name.endswith('.txt'):
            file_path = os.path.join(folder_path, file_name)
            with open(file_path, 'r', encoding='utf-8') as file:
                text = file.read()
                all_text += text
    return all_text

# 数据预处理
def preprocess_text(text):
    # 删除隐藏符号（如换行符、分页符等）
    text = re.sub(r'\s+', '', text)

    # 删除文中的标点符号
    text = re.sub(r'[^\u4e00-\u9fa5]', '', text)

    # 删除空格
    text = text.replace(' ', '')

    return text

# 计算条件熵
def calculate_conditional_entropy(tokens, n):
    conditional_counts = Counter(zip(*[tokens[i:] for i in range(n)]))
    token_count = len(tokens)
    conditional_entropy = 0
    for gram, count in conditional_counts.items():
        probability = count / token_count
        conditional_entropy += -probability * math.log(probability, 2)
    return conditional_entropy

# 计算信息熵
def calculate_entropy(tokens):
    token_count = len(tokens)
    word_counts = Counter(tokens)
    entropy = 0
    for count in word_counts.values():
        probability = count / token_count
        entropy += -probability * math.log(probability, 2)
    return entropy

# # 计算中文字单位的1-gram，2-gram和3-gram的平均信息熵
# def calculate_average_entropy(tokens):
#     n_values = [1, 2, 3]
#     total_entropy = 0
#     for n in n_values:
#         if len(tokens) >= n:
#             conditional_entropy = calculate_conditional_entropy(tokens, n)
#             total_entropy += conditional_entropy
#     average_entropy = total_entropy / len(n_values)
#     return average_entropy

# 文件夹路径
folder_path = '2'

# 读取并整合所有txt文件中的文本
all_text = read_folder(folder_path)

# 数据预处理
preprocessed_text = preprocess_text(all_text)

# 使用jieba分词
tokens_character = list(preprocessed_text)  # 以中文字为单位的tokens
tokens_word = jieba.lcut(preprocessed_text)  # 以词语为单位的tokens

# 计算信息熵和条件信息熵
for tokens, unit in [(tokens_character, 'Character'), (tokens_word, 'Word')]:
    # 计算信息熵
    entropy = calculate_entropy(tokens)
    print(f'\nEntropy for all files ({unit} unit): {entropy}')

    # 输出1-gram模型中频率前10的词语
    print(f'\nTop 10 most frequent words in 1-gram model ({unit} unit):')
    top_10_words_1gram = Counter(tokens).most_common(10)
    for word, count in top_10_words_1gram:
        print(f'{word}: {count}')

    # 输出2-gram模型的信息熵
    if len(tokens) >= 2:
        conditional_entropy_2gram = calculate_conditional_entropy(tokens, 2)
        print(f'Conditional Entropy for 2-gram model ({unit} unit): {conditional_entropy_2gram}')
    # 输出2-gram模型中频率前10的词语
    print(f'\nTop 10 most frequent words in 2-gram model ({unit} unit):')
    tokens_2gram = [tuple(tokens[i:i+2]) for i in range(len(tokens) - 1)]
    top_10_words_2gram = Counter(tokens_2gram).most_common(10)
    for word, count in top_10_words_2gram:
        print(f'{word}: {count}')

    # 输出3-gram模型的信息熵
    if len(tokens) >= 3:
        conditional_entropy_3gram = calculate_conditional_entropy(tokens, 3)
        print(f'Conditional Entropy for 3-gram model ({unit} unit): {conditional_entropy_3gram}')
    # 输出3-gram模型中频率前10的词语
    print(f'\nTop 10 most frequent words in 3-gram model ({unit} unit):')
    tokens_3gram = [tuple(tokens[i:i+3]) for i in range(len(tokens) - 2)]
    top_10_words_3gram = Counter(tokens_3gram).most_common(10)
    for word, count in top_10_words_3gram:
        print(f'{word}: {count}')

    # # 计算中文字单位的1-gram，2-gram和3-gram的平均信息熵
    # average_entropy = calculate_average_entropy(tokens)
    # print(f'\nAverage entropy for Chinese 1-gram, 2-gram, and 3-gram ({unit} unit): {average_entropy}')
